import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class CuadroMagico {

	public static BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String [] args)throws IOException{
	
	
		
	
		System.out.println("Cantidad del renglones?");
		int x = Integer.parseInt(entrada.readLine());	
		System.out.println("Cantidad del columnas?");
		int y = Integer.parseInt(entrada.readLine());	

while(x>0&&y>0){
		int a[][] = new int [x][y];
		if(a.length == a[0].length){
			ingreseValores (a);
			formula (a);
			despliega (a);}
			else{
			System.out.println("\n"+"Los valores NO corresponden a un cuadrado m�gico"+"\n");
}		
		
		System.out.println("Cantidad del renglones?");
		x = Integer.parseInt(entrada.readLine());	
		System.out.println("Cantidad del columnas?");
		y = Integer.parseInt(entrada.readLine());
	}
		
	System.out.println("Fin del Programa");
	}
	
	public static void despliega ( int [][] a)
	{
		String s="";
		for ( int r = 0; r < a.length; r++){
			for ( int c = 0; c < a[r].length; c++){
				s+=a[r][c]+"  ";}
		s+="\n";}
			System.out.println(s);
		
	}
	
	public static void ingreseValores ( int [][] a)throws IOException
	{
		for(int r=0;r<a.length;r++){
			System.out.println("Ingrese los valores por para el renglon "+r+" : ");
			for(int c=0;c<a[r].length;c++){
				int x = Integer.parseInt(entrada.readLine());
				a[r][c]=x;
			}
		}
		
	}
	
	public static void formula (int[][]a)
	{
		int n = a.length;
		int n2= a.length-1;
		int z = (n*(n*n+1))/2;
		int contador=15;
		boolean salir=false;
		
		int cuentale=0;
		while(!salir&&cuentale<n){
			contador=0;
			for(int r=0;r<n;r++){
			contador+=a[r][cuentale];}
			cuentale++;
			if(contador!=z)
				salir=true;
			
		}
		
			
		int cuentale1=0;
		while(!salir&&cuentale1<n){
				contador=0;
				for(int r=0;r<n;r++){
				contador+=a[cuentale1][r];}
				cuentale1++;
				if(contador!=z){
					salir=true;}
			}
			
		int cuentale2=0;
		while(!salir&&cuentale2<1){
			contador=0;
			for(int r=0;r<n;r++){
			contador+=a[r][r];}
			cuentale2++;
			salir=true;
		}
			
		int cuentale3=0;
		while(!salir&&cuentale3<1){
			contador=0;
			for(int r=0;r<n;r++){
			contador+=a[n2-r][n2-r];}
			cuentale3++;
			salir=true;
		}
		
		
		if(z!=contador)
			System.out.println("\n"+"Los valores NO corresponden a un cuadrado m�gico");
		else{
			System.out.println("\n"+"Los valores SI corresponden a un cuadrado m�gico");
	}
	}
	}
	
	
	

