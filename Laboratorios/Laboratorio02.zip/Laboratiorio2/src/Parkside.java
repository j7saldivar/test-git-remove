

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Parkside {

	public static BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String[] args)throws IOException {

		System.out.println("N?");
		int x = Integer.parseInt(entrada.readLine());
		System.out.println("S?");
		int y = Integer.parseInt(entrada.readLine());
		
	while((x>=1&&x<=20)&&(y>=1&&y<=9)){ 
		int a[][] = new int [x][x];
		formula(a,y);
		despliega(a);
		System.out.println("N?");
		x = Integer.parseInt(entrada.readLine());
		System.out.println("S?");
		y = Integer.parseInt(entrada.readLine());
	}
	}
	
	public static void formula(int a[][],int b){
		
		int r;
		
		for(int c=0;c<a[0].length;c++){
		r=0;
			while(r<=c){
				if(b>9){
					b=1;
				}
				
		a[r][c]=b;
		r++;
		b++;
		
		}
		
		}
		
	}
	public static void despliega (int [][] a){
		String s="";
		for ( int r = 0; r < a.length; r++){
			for ( int c = 0; c < a[r].length; c++){
				if(a[r][c]==0)
					s+="   ";
				else
				s+=a[r][c]+"  ";
			}
			
		s+="\n";}
			System.out.println(s);
		
	}
}
